echo "Executing LeApp init scripts"
