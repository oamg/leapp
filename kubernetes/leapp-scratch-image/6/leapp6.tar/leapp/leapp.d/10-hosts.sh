cat >> /etc/hosts 2> /dev/null << EOF

## Following records were copied from /etc/hosts.source file.
## In order to make any permanent changes, please edit the
## /etc/hosts.source file.

EOF
cat /etc/hosts.source >> /etc/hosts 2> /dev/null
